# MotorControl
Arduino code for sending PWM to SPARK motor controllers
